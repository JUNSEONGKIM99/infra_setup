#!/bin/sh
echo "aibiz12#$" | sudo -S pwd >> /dev/null # sudo명령 준비