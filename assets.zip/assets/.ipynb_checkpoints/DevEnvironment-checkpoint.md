# 개발환경

## 1. VSCode Extension 설치
| **Extension**                 | **설명**                           |**PC**|**서버**|
|-------------------------------|------------------------------------|-----|--------|
| **Project Manager**           | 프로젝트를 관리                     | O   | X 
| **Bookmarks**                 | 코드 파일에서 북마크 관리            | O   | X 
| **vscode-icons**              | VSCode 파일 및 폴더 아이콘          | O   | X 
| **Code Spell Checker**        | 코드 내 철자 오류를 자동 감지        | O   | X 
| **Remote SSH**                | 원격 서버에 SSH 연결                | O   | X 
| **Docker**                    | Docker 컨테이너 관리                | O   | O
| **Dev Containers**            | 컨테이너 기반 개발 환경              | X   | O
| **Git Lens/Git Graph**        | Git 히스토리 시각화 및 작업 흐름     | X   | X
| **Python**                    | Python 개발 환경                    | O   | O
| **Jupyter**                   | Jupyter Notebook                   | O   | O
| **SQLTools**                  | 다양한 데이터베이스 연결 및 쿼리 도구 | X   | X
| **SQLTools PostgreSQL**       | SQLTools PostgreSQL 드라이버        | X   | X
| **Trino Driver**              | SQLTools Trino 드라이버             | X   | X
| **ERD Editor**                | 데이터베이스 관계 시각화 도구         | O   | X
| **Draw.io Integration**       | 도식화 작업을 위한 다이어그램 생성    | O   | X

## 2. WSL 설치
### 2.1. WSL 설치(안해도 됨)
- "제어판"→"프로그램"→"프로그램 및 기능"→"windows 기능 켜기/끄기"에서 다음을 체크

  > Linux용 Windows 하위 시스템
 
  > 가상머신 플랫폼
- 체크하고 확인을 클릭 시 설치 후 재부팅

 ### 2-2. Linux 설치
- "Microsoft Store"에서 Unbuntu 24.04.1 LTS를 설치
- 설치 완료 후 PowerShell을 관리자 권한으로 실행
``` bash
wsl --install -d Ubuntu-24.04
```
### 2-4. 배포판 업데이트
``` bash
wsl
cat /etc/os-release
sudo apt update && sudo apt upgrade -y
```
### 2-3. VSCode에서 WLS2 연동
- vscode 실행 후 "확장" 탭으로 이동하여 "WSL"을 설치
- vscode에서 "ctrl + shift + p" 명령 입력 후 "WSL: WSL에 연결"을 선택
- WSL 연결에 완료되면 vscode 좌측 하단에 표시됨
- "폴더 열기"를 선택하여 작업할 폴더를 선택
- 이후 필요한 패키지를 설치하고 개발 환경을 구성하여 작업

### 2-4. WSL 시작/종료
- WSL 종료 명령
``` bash
  wsl --shutdown
```
- WSL 시작 명령
``` bash
  wsl
```

``` bash
#  SSH 키 생성
ssh-keygen -t rsa -b 4096 -C "jslee@ai-biz.net"
# 생성된 키 확인
cd .ssh
ls -al
# 서버로 복사
ssh-copy-id -i ~/.ssh/aibiz_rnd.key aibiz@10.10.10.16

# 수동으로 저장시
# .pub 파일(Public key)을 ~/.ssh/authorized_keys에 추가
# sudo vi ~/.ssh/authorized_keys
# sudo chmod 600 ~/.ssh/authorized_keys
```
- 무한로딩 문제
``` bash
# Kill server processes
kill -9 $(ps aux | grep vscode-server | grep $USER | grep -v grep | awk '{print $2}')

# Delete related files and folder
rm -rf $HOME/.vscode-server
```
## 3. GitLab 설정
### 3-1. .gitignore 파일 생성 및 폴더 제외 설정
``` bash
# 프로젝트 루트 디렉토리에 .gitignore 파일 생성:
vi .gitignore
# 제외할 폴더: 전체
folder_to_exclude/

# 특정 파일
secret_file.txt
```

### 3-2. 로컬 저장소 초기화 및 GitLab 원격 저장소 연결
``` bash
#프로젝트 폴더로 이동:
cd /path/to/your/project

#로컬 Git 저장소 초기화
git init

#GitLab 글로벌 환경 지정
git config --global user.name "jslee"
git config --global user.email "jslee@ai-biz.net"
git config --global credential.helper store

#GitLab 원격 저장소를 추가
git remote add origin http://jslee@10.10.20.14:9000/jslee/datainfra.git

#GitLab 원격 저장소를 변경
git remote add origin http://jslee@10.10.20.14:9000/jslee/datainfra.git
```

### 3-3. 변경 사항 커밋
``` bash
#.gitignore 적용 후 상태 확인:
git status

#변경 사항을 Stage 영역에 추가:
git add .

#변경 사항을 커밋:
git commit -m "Initial commit"
```
### -4. 원격 저장소로 Push
``` bash
#GitLab에 변경 사항 Push:
git branch -M main
git pull origin main --allow-unrelated-histories --no-rebase
git push -u origin main

# 앞으로 변경시
git commit -m "test2"
git push
``` 

